#pragma once

void graphicsMainLoop();

void cleanupDirectX();
