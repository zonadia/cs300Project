/* Start Header -------------------------------------------------------
Copyright (C) 2018 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior written
consent of DigiPen Institute of Technology is prohibited.
File Name: README.txt
Purpose: Readme file
Language: Visual Studio 2017 C++
Platform: Compiler : Visual Studio C++ 14.0
Hardware must support DirectX 11
Operating System requirement: Windows
Project: allie.hammond_CS300_2
Author: Allie Hammond (allie.hammond) (180009414)
Creation date: 10/28/2018
End Header --------------------------------------------------------*/


a. When setting a light to be a directional light or spotlight, the actual light orb is meaningless and the direction is set with 3 floats in the light options

b. I assume the model files and the shader files exist and are valid .obj files.

c. I completed phong lighting, phong shading, and blinn shading as well as creating a plane underneath the model
   I also created options for selecting various light and scene settings

d. I did not complete the texture loading, texture display, or projection options because I ran out of time.

e. My shaders along with all my source and header files are located in the folder /CS300.
   Models must be placed in the /CS300/models folder.

f. One of the computers in the ZZ section of Edison.

g. I started working on it Thursday October 18th, completed it Sunday October 28th, and spent about 15-20 hours working on it

h. None
